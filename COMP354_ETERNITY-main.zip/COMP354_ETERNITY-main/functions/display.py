from tkinter import *
import math
from statistics import *
expression=""
A = 0
B= 0
X= 0
values=[]
def configureWindow(window):

    previousInputFrame = Frame(window, width=400, height=50, bg='grey85')
    previousInputFrame.pack(side=TOP)

    inputFrame = Frame(window, width=400, height=70, bg='grey60')
    inputFrame.pack(side=TOP)

    input = StringVar()
 
    previousResultField = Label(previousInputFrame)
    inputField = Label(inputFrame, font=('arial', 18, 'bold'), textvariable=input, justify=RIGHT)
    
    inputField.grid(row=0, column=0)
    inputField.pack(ipady=10) # 'ipady' is internal padding to increase the height of input field

    
    
    buttonFrame = Frame(window, width=400, height=500, bg='grey90')
    buttonFrame.pack(side=BOTTOM)
    
    

    def bt_clear():
        global expression
        expression=""
        input.set("")

    def btn_erase():
        global expression
        global values
        expression=""
        input.set("")
        values=[]        
    
    def btn_click(item):
        global expression
        expression = expression + str(item)
        input.set(expression)

    def bt_equal():
        global expression
        result = str(eval(expression))
        input.set(result)
        expression=""

    def factorial(n):
        if n ==0:
            return 1
        else:
            return n* factorial(n-1)


    def btn_arccos():
        global expression
        expression =float(expression)
        result = (3.141592653589793/2) - expression
        sign= 1
        power = expression

        for i in range(1, 1000):
            sign *= -1
            power *= expression * expression
            term = sign * power / (2 * i+1)
            result += term

        input.set(result)
        expression=""

    
    def btn_sinh():
        global expression
        expression = float(expression)
        e = 2.718281828459
        result = ((e**expression)-(1/e**expression))/2
        input.set(result)
        expression=""


    def btn_A():
        global expression
        global A
        A = expression
        expression =""

    def btn_B():
        global expression
        global B
        B = expression
        expression=""

    def btn_X():
        global expression
        global X
        X = expression
        expression=""
    
    def btn_Y():
        global expression
        global Y
        Y = expression
        expression=""


    def btn_XY():
        global X
        global Y
        X = float(X)
        Y = float(Y)
        result = str(X**Y)
        input.set(result)
        expression=""

    def btn_ABY():
        global Y
        global A
        global B
        Y = float(Y)
        A = float(A)
        B = float(B)
        result = str(A*(B**Y))
        input.set(result)
        expression=""

    def btn_log():
        global B
        global X
        X = int(X)
        B = int(B)
        
        if X<=0 or B<=0:
            expression="error"
        
        numerator =0
        denominator =0

        while X>= B:
            X /= B
            numerator +=1

        for i in range(1,1000):
            if i%2 ==1:
                answer =((X-1) ** i)/i
                denominator += answer
            else:
                answer= ((X-1) ** i)/i
                numerator += answer

        result= numerator -denominator*2
        input.set(result)
        expression=""


    def btn_gamma():
        global expression
        expression = int(expression)
        result = factorial(expression-1)
        input.set(result)
        expression=""
        
    def btn_Store():
        global values
        global expression
        values.append(float(expression))
        expression=""

        

    def btn_MAD():
        global values
        median_values = sum(values)/(len(values))
      
        dev=0
        for number in values:
            dev = dev+abs(number - median_values)
        mad = dev/len(values)
        input.set(mad)
        expression=""

    
   

    def bt_standard():
        global values
        mean = sum(values)/len(values)
        variance = sum(pow(x - mean,2) for x in values)/(len(values)-1)
        std = (variance) **0.5
        input.set(std)
        expression=""





    clear = Button(buttonFrame, text = 'C', width = 9, height = 3, bd = 0, bg = '#eee', font='arial 12', command = lambda: bt_clear()).grid(row = 0, column = 0, padx = 1, pady = 1)
    arccosx = Button(buttonFrame, text ='arccosx', width=9, height=3, bd=0, bg='#eee', font= 'arial 12', command=lambda:btn_arccos()).grid(row=0, column=1, padx=1,pady=1)
    sinh = Button(buttonFrame, text ='sinh', width=9, height=3, bd=0, bg='#eee', font= 'arial 12', command=lambda:btn_sinh()).grid(row=0, column=2, padx=1,pady=1)
    divide = Button(buttonFrame, text = '/', width = 9, height = 3, bd = 0, bg = '#eee', font='arial 12', command = lambda: btn_click('/')).grid(row = 0, column = 3, padx = 1, pady = 1)
    valueA = Button(buttonFrame, text='A', width = 9, height = 3, bd = 0, bg = '#eee', font='arial 12', command = lambda: btn_A()).grid(row = 0, column = 4, padx = 1, pady = 1)
    valueB = Button(buttonFrame, text='B', width = 9, height = 3, bd = 0, bg = '#eee', font='arial 12', command = lambda: btn_B()).grid(row = 0, column = 5, padx = 1, pady = 1)
    array = Button(buttonFrame, text='Store',width=9, height=3, bd=0, bg='#eee', font= 'arial 12', command= lambda:btn_Store()).grid(row=0,column=6,padx=1,pady=1)


    num7 = Button(buttonFrame, text = '7', width = 9, height = 3, bd = 0, bg = 'grey100', font='arial 12 bold', command = lambda: btn_click(7)).grid(row = 1, column = 0, padx = 1, pady = 1)
    num8 = Button(buttonFrame, text = '8', width = 9, height = 3, bd = 0, bg = 'grey100', font='arial 12 bold', command = lambda: btn_click(8)).grid(row = 1, column = 1, padx = 1, pady = 1)
    num9 = Button(buttonFrame, text = '9', width = 9, height = 3, bd = 0, bg = 'grey100', font='arial 12 bold', command = lambda: btn_click(9)).grid(row = 1, column = 2, padx = 1, pady = 1)
    multiply = Button(buttonFrame, text = '*', width = 9, height = 3, bd = 0, bg = '#eee', font='arial 12', command = lambda: btn_click('*')).grid(row = 1, column = 3, padx = 1, pady = 1)
    logbx = Button(buttonFrame, text='LOGb(x)', width = 9, height = 3, bd = 0, bg = '#eee', font='arial 12', command = lambda: btn_log()).grid(row = 1, column = 4, padx = 1, pady = 1)
    valueX = Button(buttonFrame, text='X', width = 9, height = 3, bd = 0, bg = '#eee', font='arial 12', command = lambda: btn_X()).grid(row = 1, column = 5, padx = 1, pady = 1)
    valueY = Button(buttonFrame, text='Y', width = 9, height = 3, bd = 0, bg = '#eee', font='arial 12', command = lambda: btn_Y()).grid(row = 2, column = 5, padx = 1, pady = 1)
    erase = Button(buttonFrame, text='Erase',width=9, height=3, bd=0, bg='#eee', font= 'arial 12', command= lambda:btn_erase()).grid(row=1,column=6,padx=1,pady=1)




    num4 = Button(buttonFrame, text = '4', width = 9, height = 3, bd = 0, bg = 'grey100', font='arial 12 bold', command = lambda: btn_click(4)).grid(row = 2, column = 0, padx = 1, pady = 1)
    num5 = Button(buttonFrame, text = '5', width = 9, height = 3, bd = 0, bg = 'grey100', font='arial 12 bold', command = lambda: btn_click(5)).grid(row = 2, column = 1, padx = 1, pady = 1)
    num6 = Button(buttonFrame, text = '6', width = 9, height = 3, bd = 0, bg = 'grey100', font='arial 12 bold', command = lambda: btn_click(6)).grid(row = 2, column = 2, padx = 1, pady = 1)
    minus = Button(buttonFrame, text = '-', width = 9, height = 3, bd = 0, bg = '#eee', font='arial 12', command = lambda: btn_click('-')).grid(row = 2, column = 3, padx = 1, pady = 1)
    GammaFunction = Button(buttonFrame, text='Γ(x)', width = 9, height = 3, bd = 0, bg = '#eee', font='arial 12', command = lambda: btn_gamma()).grid(row = 2, column = 4, padx = 1, pady = 1)
    valueXY = Button(buttonFrame, text='X^Y', width = 9, height = 3, bd = 0, bg = '#eee', font='arial 12', command = lambda: btn_XY()).grid(row = 3, column = 5, padx = 1, pady = 1)



    num1 = Button(buttonFrame, text = '1', width = 9, height = 3, bd = 0, bg = 'grey100', font='arial 12 bold', command = lambda: btn_click(1)).grid(row = 3, column = 0, padx = 1, pady = 1)
    num2 = Button(buttonFrame, text = '2', width = 9, height = 3, bd = 0, bg = 'grey100', font='arial 12 bold', command = lambda: btn_click(2)).grid(row = 3, column = 1, padx = 1, pady = 1)
    num3 = Button(buttonFrame, text = '3', width = 9, height = 3, bd = 0, bg = 'grey100', font='arial 12 bold', command = lambda: btn_click(3)).grid(row = 3, column = 2, padx = 1, pady = 1)
    plus = Button(buttonFrame, text = '+', width = 9, height = 3, bd = 0, bg = '#eee', font='arial 12', command = lambda: btn_click('+')).grid(row = 3, column = 3, padx = 1, pady = 1)
    mad= Button(buttonFrame, text='MAD', width = 9, height = 3, bd = 0, bg = '#eee', font='arial 12', command = lambda: btn_MAD()).grid(row = 3, column = 4, padx = 1, pady = 1)
    valueABY = Button(buttonFrame, text='AB^Y', width = 9, height = 3, bd = 0, bg = '#eee', font='arial 12', command = lambda: btn_ABY()).grid(row = 4, column = 5, padx = 1, pady = 1)
    standard = Button(buttonFrame, text = 'σ', width = 9, height = 3, bd = 0, bg = '#eee', font='arial 12', command = lambda: bt_standard()).grid(row = 4, column = 4, padx = 1, pady = 1)


    negate = Button(buttonFrame, text = '+/-', width = 9, height = 3, bd = 0, bg = 'grey100', font='arial 12 bold', command = lambda: btn_click(0)).grid(row = 4, column = 0, padx = 1, pady = 1)
    num0 = Button(buttonFrame, text = '0', width = 9, height = 3, bd = 0, bg = 'grey100', font='arial 12 bold', command = lambda: btn_click(0)).grid(row = 4, column = 1, padx = 1, pady = 1)
    dot = Button(buttonFrame, text = '.', width = 9, height = 3, bd = 0, bg = 'grey100', font='arial 12 bold', command = lambda: btn_click('.')).grid(row = 4, column = 2, padx = 1, pady = 1)
    equal = Button(buttonFrame, text = '=', width = 9, height = 3, bd = 0, bg = 'lightblue', font='arial 12', command = lambda: bt_equal()).grid(row = 4, column = 3 ,padx = 1, pady = 1)
